import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product-services/product.service';
import { Product } from '../product-model/product.model';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  product: Product | undefined;
  enrichedDescription: string | undefined;
  tone: string = 'neutral';
  length: string = 'medium';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService
  ) { }

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.productService.getProduct(id).subscribe(data => {
      this.product = data;
    });
  }

  enrichDescription(): void {
    if (this.product) {
      this.productService.enrichProductDescription(this.product.id!, { tone: this.tone, length: this.length }).subscribe(data => {
        this.enrichedDescription = data.description;
      });
    }
  }

  saveEnrichedDescription(): void {
    if (this.product && this.enrichedDescription) {
      this.product.description = this.enrichedDescription;
      this.productService.updateProduct(this.product.id!, this.product).subscribe();
    }
  }

  deleteProduct(): void {
    if (this.product && confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) {
      this.productService.deleteProduct(this.product.id!).subscribe(() => {
        this.router.navigate(['/products']);
      });
    }
  }

  goBack(): void {
    this.router.navigate(['/products']);
  }
}
